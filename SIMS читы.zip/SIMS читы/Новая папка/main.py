# main.py - Точка входа, окно авторизации
import sys
from PyQt6 import uic
from PyQt6.QtWidgets import QApplication, QMainWindow, QMessageBox
from auth import check_user # функция проверки логина/пароля

class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("ui/login.ui", self)

        # Подключение кнопок к методам
        self.loginBtn.clicked.connect(self.login)
        self.guestBtn.clicked.connect(self.guest)

    # Обработка нажатия кнопки 'Войти'
    def login(self):
        # Получаем текст из полей ввода, убираем лишние пробелы
        login = self.loginLine.text().strip()
        password = self.passwordLine.text().strip()

        # Проверяем, что поля не пустые
        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин и пароль")
            return

        user = check_user(login, password) # функция проверки пользователя

        # Если пользователь найден, открываем главное окно с его ролью и ID
        if user:
            self.open_main(user["role"], user["fio"], user["id"])
        else:
            QMessageBox.warning(self, "Ошибка", "Неверные данные")

    # главное окно с ролью 'guest' и без ID пользователя
    def guest(self):
        self.open_main("guest", "Гость", None)

    # Открывает главное окно каталога товаров с переданными параметрами
    def open_main(self, role, fio, user_id):
        from products_window import ProductsWindow # класс ProductsWindow из products_window.py
        self.window = ProductsWindow(role, fio, user_id)
        self.window.show()
        self.close() # Закрываем текущее окно входа

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())
# orders_window.py — Управление заказами
from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox, QComboBox
from PyQt6.QtCore import QDate
from db import get_connection # Импорт функции получения соединения с БД из нашего модуля db

class OrdersWindow(QMainWindow):
    def __init__(self, role, user_id=None):
        super().__init__()
        uic.loadUi("ui/orders_window.ui", self)
        self.role = role
        self.user_id = user_id
        self._loading = False
        self.date_filter_active = False # Флаг, показывающий, выбрал ли пользователь дату вручную (для фильтрации)

        # Настройка виджета выбора даты (по умолчанию пусто)
        self.sort_date.setDate(QDate.currentDate()) # временно ставим текущую дату
        self.sort_date.setSpecialValueText("Все даты") # текст, когда дата не выбрана
        self.sort_date.setCalendarPopup(True) # разрешаем выпадающий календарь
        self.sort_date.setDate(QDate()) # сбрасываем на пустую дату (показываем все)

        # Заполняем выпадающие списки фильтров (статусы, клиенты)
        self.load_filters()
        self.load_orders() # Первичная загрузка заказов из БД

        # Подключаем сигналы изменения фильтров к методу перезагрузки заказов
        self.poisk.textChanged.connect(self.load_orders) # поиск по тексту
        self.sort_status.currentIndexChanged.connect(self.load_orders) # выбор статуса
        self.sort_client.currentIndexChanged.connect(self.load_orders) # выбор клиента
        self.sort_date.dateChanged.connect(self.on_date_changed) # изменение даты

        # Настраиваем видимость элементов в зависимости от роли
        self.setup_by_role()

    # вызывается при изменении даты в виджете QDateEdit
    def on_date_changed(self, date):
        self.date_filter_active = not date.isNull() #  Устанавливает флаг date_filter_active, если дата не пустая
        self.load_orders() # перезагружаем заказы с учётом нового фильтра

    # Загружает данные для выпадающих списков фильтров:
    # статусы заказов (для всех ролей, кроме client), список клиентов (только для manager и admin)
    def load_filters(self):
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                # Получаем все статусы из таблицы order_statuses
                cursor.execute("SELECT * FROM order_statuses")
                # Добавляем пункт "Все статусы" (значение None)
                self.sort_status.addItem("Все статусы", None)
                for s in cursor.fetchall():
                    self.sort_status.addItem(s["name"], s["id"])

                # Если роль не клиент, заполняем список клиентов (пользователи с role_id=2)
                if self.role != "client":
                    cursor.execute("SELECT * FROM users WHERE role_id=2")
                    self.sort_client.addItem("Все клиенты", None)
                    for u in cursor.fetchall():
                        self.sort_client.addItem(u["fio"], u["id"])
                else:
                    # Для клиента скрываем комбобокс выбора клиента (он видит только свои заказы)
                    self.sort_client.hide()
        finally:
            conn.close()

    # Основной метод загрузки и отображения заказов. Формирует SQL-запрос с учётом всех активных фильтров и заполняет таблицу
    def load_orders(self):
        # Защита от повторного входа (если метод уже выполняется)
        if self._loading:
            return
        self._loading = True

        try:
            # Получаем значения из фильтров
            search = self.poisk.text().strip() # текст поиска
            status_id = self.sort_status.currentData() if self.role != "client" else None
            client_id = self.sort_client.currentData() if self.role != "client" else None
            date = self.sort_date.date() # выбранная дата (может быть пустой)

            # Базовый SQL-запрос: выбираем заказы с информацией о клиенте и статусе
            query = """
                SELECT o.id, u.fio, o.order_date, os.name AS status,
                       o.total_price, o.address, o.payment_method, o.status_id
                FROM orders o
                JOIN users u ON o.user_id = u.id
                JOIN order_statuses os ON o.status_id = os.id
                WHERE 1=1
            """
            params = [] # список параметров для подстановки в запрос

            # Для клиента добавляем условие – только его заказы
            if self.role == "client" and self.user_id:
                query += " AND o.user_id = %s"
                params.append(self.user_id)

            # Если в поле поиска есть текст, ищем по ФИО клиента или адресу
            if search:
                query += " AND (u.fio LIKE %s OR o.address LIKE %s)"
                params.extend([f"%{search}%", f"%{search}%"])

            # Фильтр по статусу (если выбран конкретный статус)
            if status_id is not None:
                query += " AND o.status_id = %s"
                params.append(status_id)

            # Фильтр по клиенту (для менеджера/админа)
            if client_id is not None:
                query += " AND o.user_id = %s"
                params.append(client_id)

            # Фильтр по дате – применяется только если дата выбрана вручную и не пустая
            if self.role != "client" and self.date_filter_active and not date.isNull():
                query += " AND o.order_date = %s"
                params.append(date.toString("yyyy-MM-dd"))

            # Сортировка: для клиента – сначала новые, завершённые внизу (id=4)
            if self.role == "client":
                query += " ORDER BY o.order_date DESC, os.id = 4, os.id"
            else:
                query += " ORDER BY o.order_date DESC"

            # Выполняем запрос к БД
            conn = get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute(query, params)
                    orders = cursor.fetchall() # получаем все найденные заказы
            finally:
                conn.close()

            # Определяем количество колонок в таблице: для менеджера и админа добавляем колонку "Сменить статус"
            if self.role in ("manager", "admin"):
                col_count = 8  # добавляем колонку для смены статуса
            else:
                col_count = 7

            # Очищаем таблицу и задаём количество колонок
            self.tableWidget.setRowCount(0)
            self.tableWidget.setColumnCount(col_count)

            # Заголовки столбцов
            headers = ["ID", "Клиент", "Дата", "Статус", "Сумма", "Адрес", "Оплата"]
            if col_count == 8:
                headers.append("Сменить статус")
            self.tableWidget.setHorizontalHeaderLabels(headers)

            # Построчно заполняем таблицу данными
            for row, order in enumerate(orders):
                self.tableWidget.setRowCount(row + 1) # добавляем строку
                self.tableWidget.setItem(row, 0, QTableWidgetItem(str(order["id"])))
                self.tableWidget.setItem(row, 1, QTableWidgetItem(order["fio"]))
                self.tableWidget.setItem(row, 2, QTableWidgetItem(str(order["order_date"])))
                self.tableWidget.setItem(row, 3, QTableWidgetItem(order["status"]))
                self.tableWidget.setItem(row, 4, QTableWidgetItem(str(order["total_price"])))
                self.tableWidget.setItem(row, 5, QTableWidgetItem(order["address"]))
                self.tableWidget.setItem(row, 6, QTableWidgetItem(order["payment_method"]))

                # Для менеджера/админа добавляем выпадающий список смены статуса
                if col_count == 8:
                    combo = QComboBox() # Создаём выпадающий список со статусами
                    conn2 = get_connection() # Загружаем статусы из БД
                    try:
                        with conn2.cursor() as cur:
                            cur.execute("SELECT id, name FROM order_statuses")
                            for st in cur.fetchall():
                                combo.addItem(st["name"], st["id"])
                    finally:
                        conn2.close()

                    index = combo.findData(order["status_id"]) # Устанавливаем текущий статус заказа
                    if index >= 0:
                        combo.setCurrentIndex(index)
                    # При изменении статуса вызываем update_status
                    combo.currentIndexChanged.connect(lambda idx, oid=order["id"], cb=combo: self.update_status(oid, cb))
                    self.tableWidget.setCellWidget(row, 7, combo)

            # Для клиента разрешаем двойной клик по строке для просмотра состава заказа
            if self.role == "client":
                self.tableWidget.cellDoubleClicked.connect(self.show_order_items)
            self.tableWidget.resizeColumnsToContents() # Автоматически подгоняем ширину столбцов под содержимое
        finally:
            self._loading = False # сбрасываем флаг загрузки

    # Обновляет статус заказа в БД. Вызывается при изменении выбранного статуса в комбобоксе
    def update_status(self, order_id, combo):
        new_status_id = combo.currentData()
        if new_status_id is None:
            return
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("UPDATE orders SET status_id=%s WHERE id=%s", (new_status_id, order_id))
                conn.commit()
            QMessageBox.information(self, "Успех", "Статус обновлён")
            self.load_orders() # перезагружаем таблицу
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось обновить статус: {e}")
        finally:
            conn.close()

    # Открывает окно с составом заказа при двойном клике по строке (только для клиента)
    def show_order_items(self, row, col):
        from order_items_window import OrderItemsWindow
        order_id = int(self.tableWidget.item(row, 0).text()) # получаем ID заказа из первой колонки
        self.order_items_window = OrderItemsWindow(order_id)
        self.order_items_window.show()

    # Настраивает видимость элементов интерфейса в зависимости от роли пользователя
    def setup_by_role(self):
        # Скрываем кнопку edit_status полностью (она не используется)
        self.edit_status.hide()
        # Для клиента скрываем фильтры по дате, статусу и поле поиска (он видит только свои заказы)
        if self.role == "client":
            self.sort_date.hide()
            self.sort_status.hide()
            self.poisk.hide()
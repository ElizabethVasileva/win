# auth.py - Проверка учётных данных
from db import get_connection

def check_user(login, password): # проверка логина и пароля
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT users.*, roles.name AS role
                FROM users
                JOIN roles ON users.role_id = roles.id
                WHERE login=%s AND password=%s
            """, (login, password))
            return cursor.fetchone() # возвращает первую найденную строку или None
    finally:
        conn.close() # В любом случае закрываем соединение
# order_items_window.py — Окно состава заказа
from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem
from db import get_connection

class OrderItemsWindow(QMainWindow):
    def __init__(self, order_id):
        super().__init__()
        uic.loadUi("ui/order_items_window.ui", self)
        self.order_id = order_id # Сохраняем ID заказа в атрибут экземпляра
        self.load_items() # Вызываем метод загрузки и отображения позиций заказа

    # Загружает из БД список товаров для текущего заказа и заполняет таблицу
    def load_items(self):
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                # SQL-запрос: выбираем название товара, количество, цену за единицу и общую стоимость позиции
                cursor.execute("""
                    SELECT p.name, oi.quantity, oi.price, (oi.quantity * oi.price) as total
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    WHERE oi.order_id = %s
                """, (self.order_id,))
                items = cursor.fetchall() # Получаем все строки результата запроса

                self.tableWidget.setRowCount(len(items)) # Устанавливаем количество строк в таблице равным количеству найденных позиций
                self.tableWidget.setColumnCount(4) # Устанавливаем количество колонок: 4 (Товар, Кол-во, Цена, Сумма)
                self.tableWidget.setHorizontalHeaderLabels(["Товар", "Кол-во", "Цена", "Сумма"]) # Задаём заголовки столбцов

                total_sum = 0 # Переменная для подсчёта итоговой суммы заказа
                # Проходим по всем позициям, row — индекс строки, item — словарь с данными
                for row, item in enumerate(items): # Заполняем ячейки таблицы
                    self.tableWidget.setItem(row, 0, QTableWidgetItem(item["name"])) # Название товара
                    self.tableWidget.setItem(row, 1, QTableWidgetItem(str(item["quantity"]))) # Количество
                    self.tableWidget.setItem(row, 2, QTableWidgetItem(f"{item['price']:.2f}")) # Цена за единицу (2 знака после запятой)
                    self.tableWidget.setItem(row, 3, QTableWidgetItem(f"{item['total']:.2f}")) # Сумма по позиции
                    total_sum += item['total'] # Прибавляем сумму позиции к общей сумме

                self.total_label.setText(f"Итого: {total_sum:.2f} руб.") # Выводим итоговую сумму в метку total_label
        finally:
            conn.close() # В любом случае закрываем соединение с БД
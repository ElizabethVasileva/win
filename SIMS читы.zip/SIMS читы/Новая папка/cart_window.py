# cart_window.py - окно корзины
from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem, QMessageBox, QPushButton, QHeaderView, QDialog
from PyQt6.QtCore import Qt
from db import get_connection


class CartWindow(QMainWindow):
    def __init__(self, cart, user_id):
        super().__init__()
        uic.loadUi("ui/cart_window.ui", self)

        self.cart = cart # ссылка на словарь корзины из главного окна
        self.user_id = user_id
        self.populate_table() # заполняем таблицу товарами
        self.update_total() # выводим итоговую сумму

        # Привязка кнопок к методам
        self.tableWidget.cellChanged.connect(self.on_cell_changed) # изменение количества в ячейке
        self.clear_cart_btn.clicked.connect(self.clear_cart)
        self.checkout_btn.clicked.connect(self.checkout)

    # Заполняет таблицу данными из self.cart
    def populate_table(self):
        self.tableWidget.blockSignals(True) # Временно отключаем сигнал cellChanged, чтобы не срабатывал при заполнении
        self.tableWidget.setRowCount(len(self.cart))
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(["Товар", "Цена", "Кол-во", "Сумма", ""])

        for row, (pid, item) in enumerate(self.cart.items()):
            # Название (нередактируемое)
            name_item = QTableWidgetItem(item["name"])
            name_item.setFlags(name_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.tableWidget.setItem(row, 0, name_item)

            # Цена (нередактируемая)
            price_item = QTableWidgetItem(f"{item['price']:.2f}")
            price_item.setFlags(price_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.tableWidget.setItem(row, 1, price_item)

            # Количество (редактируемое)
            qty_item = QTableWidgetItem(str(item["quantity"]))
            self.tableWidget.setItem(row, 2, qty_item)

            # Сумма (нередактируемая)
            sum_item = QTableWidgetItem(f"{item['price'] * item['quantity']:.2f}")
            sum_item.setFlags(sum_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.tableWidget.setItem(row, 3, sum_item)

            # Кнопка "Удалить"
            del_btn = QPushButton("Удалить")
            del_btn.clicked.connect(lambda checked, p=pid: self.remove_item(p))
            self.tableWidget.setCellWidget(row, 4, del_btn)

        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tableWidget.blockSignals(False)

    # Обрабатывает ручное изменение количества
    def on_cell_changed(self, row, col):
        if col != 2:
            return
        try:
            new_qty = int(self.tableWidget.item(row, col).text())
            if new_qty <= 0:
                raise ValueError
        except:
            QMessageBox.warning(self, "Ошибка", "Количество должно быть положительным числом")
            # Восстанавливаем старое значение
            pid = list(self.cart.keys())[row]
            old_qty = self.cart[pid]["quantity"]
            self.tableWidget.blockSignals(True)
            self.tableWidget.item(row, col).setText(str(old_qty))
            self.tableWidget.blockSignals(False)
            return

        pid = list(self.cart.keys())[row]
        self.cart[pid]["quantity"] = new_qty
        price = self.cart[pid]["price"]
        # Устанавливаем новую сумму
        sum_item = self.tableWidget.item(row, 3)
        if sum_item:
            sum_item.setText(f"{price * new_qty:.2f}")
        self.update_total()

    # Удаляет товар из корзины
    def remove_item(self, pid):
        del self.cart[pid]
        self.refresh_table()

    # Очищает корзину
    def clear_cart(self):
        self.cart.clear()
        self.refresh_table()

    # Перезагружает таблицу после изменений
    def refresh_table(self):
        self.tableWidget.blockSignals(True)
        self.tableWidget.clearContents()
        self.populate_table()
        self.update_total()
        self.tableWidget.blockSignals(False)

    # Обновляет итоговую сумму
    def update_total(self):
        total = sum(item["price"] * item["quantity"] for item in self.cart.values())
        self.total_label.setText(f"Итого: {total:.2f} руб.")

    # Открывает диалог оформления заказа
    def checkout(self):
        if not self.cart:
            QMessageBox.warning(self, "Ошибка", "Корзина пуста")
            return

        dialog = QDialog(self)
        uic.loadUi("ui/order_dialog.ui", dialog)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            address = dialog.address_edit.text().strip()
            payment = dialog.payment_combo.currentText()
            delivery = dialog.delivery_combo.currentText()
            if not address:
                QMessageBox.warning(self, "Ошибка", "Введите адрес доставки")
                return
            self.create_order(address, payment, delivery)

    # Создаёт заказ в БД и очищает корзину
    def create_order(self, address, payment, delivery):
        total = sum(item["price"] * item["quantity"] for item in self.cart.values())
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO orders
                    (user_id, order_date, status_id, total_price,
                     address, payment_method, delivery_method)
                    VALUES (%s, CURDATE(), 1, %s, %s, %s, %s)
                """, (self.user_id, total, address, payment, delivery))
                order_id = cursor.lastrowid

                for pid, item in self.cart.items():
                    cursor.execute("""
                        INSERT INTO order_items
                        (order_id, product_id, quantity, price)
                        VALUES (%s, %s, %s, %s)
                    """, (order_id, pid, item["quantity"], item["price"]))

                conn.commit()
            QMessageBox.information(self, "Успех", "Заказ оформлен")
            self.cart.clear()
            self.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось создать заказ: {e}")
        finally:
            conn.close()

    # Возвращает текущее состояние корзины
    def get_cart(self):
        return self.cart
# products_window.py - главное окно каталога
from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QMessageBox, QPushButton
from PyQt6.QtGui import QPixmap
from db import get_connection

class ProductsWindow(QMainWindow):
    def __init__(self, role, fio, user_id):
        super().__init__()
        uic.loadUi("ui/spisok_products.ui", self)

        self.role = role
        self.user_id = user_id
        self.cart = {} # корзина клиента: {product_id: {"name":..., "price":..., "quantity":...}}
        self._loading = False # защита от повторного входа в load_products()
        self.fio.setText(f"{fio} ({role})") # отображаем ФИО и роль в верхней панели

        self.setup_ui() # настройка области прокрутки
        self.load_filters() # заполнение выпадающих списков категорий и производителей
        self.load_products() # загружает и отображает карточки товаров
        self.setup_by_role() # скрывает/показывает элементы интерфейса в зависимости от роли

        # Привязка кнопок к методам
        self.exitBtn.clicked.connect(self.logout)
        self.add_product.clicked.connect(self.open_add)
        self.orders.clicked.connect(self.open_orders)
        self.analitik.clicked.connect(self.open_analytics)
        self.poisk.textChanged.connect(self.load_products)
        self.sort_category.currentIndexChanged.connect(self.load_products)
        self.sort_manufacturer.currentIndexChanged.connect(self.load_products)

    """
    Настройка интерфейса
    """
    # Контейнер с вертикальным layout для размещения карточек товаров
    def setup_ui(self):
        self.container = QWidget()
        self.layout = QVBoxLayout(self.container)
        self.scrollArea.setWidget(self.container)

    # Рекурсивно удаляет все виджеты из переданного layout
    def clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
            elif item.layout():
                self.clear_layout(item.layout())

    """
    Загрузка фильтров (категории, производители)
    """
    # Заполнение выпадающих списков категорий и производителей
    def load_filters(self):
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                # Блокируем сигналы, чтобы при добавлении элементов не дёргался (не вызывался) load_products()
                self.sort_category.blockSignals(True)
                self.sort_manufacturer.blockSignals(True)
                self.sort_category.clear()
                self.sort_manufacturer.clear()

                # Категории
                cursor.execute("SELECT id, name FROM categories")
                self.sort_category.addItem("Все категории", None) # первый пункт "Все категории" с данными None
                for cat in cursor.fetchall():
                    self.sort_category.addItem(cat["name"], cat["id"])

                # Производители
                cursor.execute("SELECT id, name FROM manufacturers")
                self.sort_manufacturer.addItem("Все производители", None)
                for man in cursor.fetchall():
                    self.sort_manufacturer.addItem(man["name"], man["id"])

                self.sort_category.blockSignals(False)
                self.sort_manufacturer.blockSignals(False)
        finally:
            conn.close()

    """
    Загрузка и отображение товаров
    """
    # Загружает товары из БД с учётом поиска и выбранных фильтров
    def load_products(self):
        if self._loading: # предотвращаем повторный вход
            return
        self._loading = True

        try:
            self.clear_layout(self.layout) # убираем старые карточки

            # Получаем текущие значения фильтров
            search_text = self.poisk.text().strip()
            category_id = self.sort_category.currentData()
            manufacturer_id = self.sort_manufacturer.currentData()

            # Запрос без JOIN с поставщиками, чтобы не было дублей
            query = """
                SELECT p.*, c.name AS category, m.name AS manufacturer
                FROM products p
                JOIN categories c ON p.category_id = c.id
                JOIN manufacturers m ON p.manufacturer_id = m.id
                WHERE 1=1
            """
            params = []

            # Добавляем условия поиска и фильтров
            if search_text:
                query += " AND (p.name LIKE %s OR p.description LIKE %s)"
                params.extend([f"%{search_text}%", f"%{search_text}%"])

            if category_id is not None:
                query += " AND p.category_id = %s"
                params.append(category_id)

            if manufacturer_id is not None:
                query += " AND p.manufacturer_id = %s"
                params.append(manufacturer_id)

            conn = get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute(query, params)
                    products = cursor.fetchall()

                    # Для каждого товара отдельно получаем его поставщиков (связь многие-ко-многим)
                    for product in products:
                        cursor.execute("""
                            SELECT s.name
                            FROM product_suppliers ps
                            JOIN suppliers s ON ps.supplier_id = s.id
                            WHERE ps.product_id = %s
                        """, (product["id"],))
                        suppliers = [row["name"] for row in cursor.fetchall()]
                        product["suppliers"] = ", ".join(suppliers) if suppliers else "-"
                        self.add_card(product) # создаём карточку
            finally:
                conn.close()
        finally:
            self._loading = False

    # Создаёт виджет карточки товара на основе product_card.ui и заполняет данными
    def add_card(self, product):
        card = QWidget()
        uic.loadUi("ui/product_card.ui", card)

        # Заполнение текстовых полей
        card.nameLabel.setText(product["name"])
        card.categoryLabel.setText(product["category"])
        card.descriptionLabel.setText(product["description"])
        card.manufacturerLabel.setText(f"Производитель: {product['manufacturer']}")
        card.supplierLabel.setText(f"Поставщик: {product.get('suppliers', '-')}")
        card.stockLabel.setText(f"Количество: {product['stock']}")
        card.priceLabel.setText(f"{product['price']} руб")

        # Загрузка изображения, если путь указан
        if product["image"]:
            card.image.setPixmap(QPixmap(product["image"]))

        # Скрываем кнопки в зависимости от роли
        if self.role == "guest":
            card.add_clientBtn.hide()
            card.editBtn.hide()
            card.deleteBtn.hide()
        elif self.role == "client":
            card.editBtn.hide()
            card.deleteBtn.hide()
        elif self.role == "manager":
            card.add_clientBtn.hide()
            card.editBtn.hide()
            card.deleteBtn.hide()
        elif self.role == "admin":
            card.add_clientBtn.hide()

        # Привязка кнопок к действиям
        card.add_clientBtn.clicked.connect(lambda checked, p=product: self.add_to_cart(p))
        card.deleteBtn.clicked.connect(lambda checked, pid=product["id"]: self.delete_product(pid))
        card.editBtn.clicked.connect(lambda checked, p=product: self.open_edit(p))

        self.layout.addWidget(card) # добавляем карточку в layout

    """
    Работа с корзиной
    """
    # Добавляет товар в корзину (увеличивает количество, если уже есть)
    def add_to_cart(self, product):
        pid = product["id"]
        if pid in self.cart:
            self.cart[pid]["quantity"] += 1
        else:
            self.cart[pid] = {
                "name": product["name"],
                "price": float(product["price"]),
                "quantity": 1
            }
        QMessageBox.information(self, "Корзина", "Товар добавлен")

    # Открывает окно корзины (только для клиента)
    def open_cart(self):
        from cart_window import CartWindow
        self.cart_window = CartWindow(self.cart, self.user_id)
        self.cart_window.show()
        # После закрытия окна обновляем self.cart из окна корзины
        self.cart_window.destroyed.connect(lambda: setattr(self, 'cart', self.cart_window.get_cart()))

    """
    Управление товарами (админ)
    """
    # Удаляет товар из БД после подтверждения
    def delete_product(self, product_id):
        reply = QMessageBox.question(self, "Подтверждение", "Удалить товар?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            conn = get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute("DELETE FROM products WHERE id=%s", (product_id,))
                    conn.commit()
                self.load_products() # обновляем каталог
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить: {e}")
            finally:
                conn.close()

    # Открывает окно добавления товара
    def open_add(self):
        from add_edit_window import AddEditWindow
        self.w = AddEditWindow(on_save=self.load_products) # после сохранения вызываем load_products
        self.w.show()

    # Открывает окно редактирования товара
    def open_edit(self, product):
        from add_edit_window import AddEditWindow
        self.w = AddEditWindow(product, on_save=self.load_products)
        self.w.show()

    """
    Переходы в другие окна
    """
    # Открывает окно заказов
    def open_orders(self):
        from orders_window import OrdersWindow
        uid = self.user_id if self.role == "client" else None
        self.w = OrdersWindow(self.role, uid)
        self.w.show()

    # Открывает окно аналитики
    def open_analytics(self):
        from analytics_window import AnalyticsWindow
        self.w = AnalyticsWindow()
        self.w.show()

    # Возврат к окну входа
    def logout(self):
        from main import LoginWindow
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()

    """
    Настройка интерфейса по роли
    """
    def setup_by_role(self):
        if self.role == "client":
            # Для клиента добавляем кнопку "Корзина"
            self.cart_btn = QPushButton("Корзина")
            self.cart_btn.setStyleSheet("background: orange")
            self.horizontalLayout_2.addWidget(self.cart_btn)
            self.cart_btn.clicked.connect(self.open_cart)

        # Скрываем ненужные кнопки и фильтры
        if self.role == "guest":
            self.add_product.hide()
            self.orders.hide()
            self.analitik.hide()
            self.poisk.hide()
            self.sort_category.hide()
            self.sort_manufacturer.hide()
        elif self.role == "client":
            self.add_product.hide()
            self.analitik.hide()
        elif self.role == "manager":
            self.add_product.hide()
            self.poisk.hide()
            self.sort_category.hide()
            self.sort_manufacturer.hide()
        elif self.role == "admin":
            self.analitik.hide()
            self.poisk.hide()
            self.sort_category.hide()
            self.sort_manufacturer.hide()
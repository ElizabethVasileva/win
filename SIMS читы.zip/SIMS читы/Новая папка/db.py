# db.py - Подключение к базе данных
import pymysql

def get_connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        database="clothing_store",
        cursorclass=pymysql.cursors.DictCursor
    )
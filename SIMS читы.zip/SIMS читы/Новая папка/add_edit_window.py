# add_edit_window.py - добавление и редактирование карточки товара
from PyQt6 import uic
from PyQt6.QtWidgets import QWidget, QFileDialog, QMessageBox
from PyQt6.QtGui import QPixmap
from db import get_connection

class AddEditWindow(QWidget):
    def __init__(self, product=None, on_save=None):
        super().__init__()
        uic.loadUi("ui/add_edit_window.ui", self)
        self.product = product # если редактирование, то передан объект товара
        self.image_path = None # путь к выбранному изображению
        self.on_save = on_save # функция обратного вызова после сохранения
        self.load_data() # заполняем комбобоксы категорий, производителей, поставщико

        # Привязка кнопок
        self.add_image.clicked.connect(self.load_image)
        self.saveBtn.clicked.connect(self.save)

        # если редактирование — заполняем поля
        if product:
            self.fill_data()

    # Загружает справочные данные из БД в комбобоксы
    def load_data(self):
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM categories")
                for c in cursor.fetchall():
                    self.category_box.addItem(c["name"], c["id"])

                cursor.execute("SELECT * FROM manufacturers")
                for m in cursor.fetchall():
                    self.manufacturer_box.addItem(m["name"], m["id"])

                cursor.execute("SELECT * FROM suppliers")
                for s in cursor.fetchall():
                    self.supplier_box.addItem(s["name"], s["id"])
        finally:
            conn.close()

    # Заполняет поля формы данными редактируемого товара
    def fill_data(self):
        self.id.setText(str(self.product["id"]))
        self.name.setText(self.product["name"])
        self.description.setText(self.product["description"])
        self.price_box.setValue(float(self.product["price"]))
        self.stock_box.setValue(self.product["stock"])

        # Устанавливаем выбранные значения в комбобоксах
        index = self.category_box.findData(self.product["category_id"])
        if index >= 0:
            self.category_box.setCurrentIndex(index)
        index = self.manufacturer_box.findData(self.product["manufacturer_id"])
        if index >= 0:
            self.manufacturer_box.setCurrentIndex(index)

        # Изображение
        if self.product["image"]:
            self.image_path = self.product["image"]
            self.image.setPixmap(QPixmap(self.image_path))

        # Поставщик (берём первого, т.к. у нас теперь один поставщик для товара)
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT supplier_id FROM product_suppliers WHERE product_id=%s LIMIT 1", (self.product["id"],))
                row = cursor.fetchone()
                if row:
                    sup_id = row["supplier_id"]
                    index = self.supplier_box.findData(sup_id)
                    if index >= 0:
                        self.supplier_box.setCurrentIndex(index)
        finally:
            conn.close()

    # Открывает диалог выбора изображения и отображает его
    def load_image(self):
        file, _ = QFileDialog.getOpenFileName(self, "Выбрать фото", "", "Images (*.png *.jpg)")
        if file:
            self.image_path = file
            self.image.setPixmap(QPixmap(file))

    # Сохраняет (добавляет или обновляет) товар в БД
    def save(self):
        name = self.name.text().strip()
        desc = self.description.text().strip()
        price = self.price_box.value()
        stock = self.stock_box.value()
        category_id = self.category_box.currentData()
        manufacturer_id = self.manufacturer_box.currentData()
        supplier_id = self.supplier_box.currentData()

        if not name:
            QMessageBox.warning(self, "Ошибка", "Введите название товара")
            return

        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                if self.product:
                    # Обновление существующего товара
                    cursor.execute("""
                        UPDATE products
                        SET name=%s, description=%s, price=%s,
                            stock=%s, category_id=%s,
                            manufacturer_id=%s, image=%s
                        WHERE id=%s
                    """, (name, desc, price, stock,
                          category_id, manufacturer_id,
                          self.image_path, self.product["id"]))
                    product_id = self.product["id"]
                else:
                    # Вставка нового товара
                    cursor.execute("""
                        INSERT INTO products
                        (name, description, price, stock,
                         category_id, manufacturer_id, image)
                        VALUES (%s,%s,%s,%s,%s,%s,%s)
                    """, (name, desc, price, stock,
                          category_id, manufacturer_id,
                          self.image_path))
                    product_id = cursor.lastrowid

                # Обновляем связь с поставщиком (удаляем старые, добавляем нового)
                cursor.execute("DELETE FROM product_suppliers WHERE product_id=%s", (product_id,))
                if supplier_id is not None:
                    cursor.execute("INSERT INTO product_suppliers (product_id, supplier_id) VALUES (%s, %s)",
                                   (product_id, supplier_id))

                conn.commit()
                QMessageBox.information(self, "Успех", "Сохранено")
                if self.on_save:
                    self.on_save() # вызываем колбэк (например, load_products в главном окне)
                self.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить: {e}")
        finally:
            conn.close()
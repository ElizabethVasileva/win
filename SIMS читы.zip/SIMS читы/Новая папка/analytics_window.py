from PyQt6 import uic
from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem
from db import get_connection

class AnalyticsWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("ui/analytics_window.ui", self)
        self.load_data() # Вызываем метод загрузки и отображения данных

    # Загружает статистические данные из БД и заполняет соответствующие виджеты
    def load_data(self):
        conn = get_connection()
        try:
            with conn.cursor() as cursor:
                # Общая сумма всех заказов
                cursor.execute("SELECT SUM(total_price) as total FROM orders")
                total = cursor.fetchone()["total"] or 0 # Получаем результат (одна строка с полем total)
                self.total_label.setText(f"Общая сумма заказов: {total:.2f} руб.") # Выводим сумму в метку total_label

                # Статистика по статусам заказов
                cursor.execute("""
                    SELECT os.name, COUNT(o.id) as cnt, COALESCE(SUM(o.total_price),0) as summa
                    FROM order_statuses os
                    LEFT JOIN orders o ON os.id = o.status_id
                    GROUP BY os.id
                """)
                statuses = cursor.fetchall() # Получаем все строки (по одной на каждый статус)
                self.status_table.setRowCount(len(statuses)) # Устанавливаем размеры таблицы статусов
                self.status_table.setColumnCount(3)
                self.status_table.setHorizontalHeaderLabels(["Статус", "Кол-во", "Сумма"])

                # Заполняем таблицу
                for i, row in enumerate(statuses):
                    self.status_table.setItem(i, 0, QTableWidgetItem(row["name"])) # Название статуса
                    self.status_table.setItem(i, 1, QTableWidgetItem(str(row["cnt"]))) # Количество заказов
                    self.status_table.setItem(i, 2, QTableWidgetItem(f"{row['summa']:.2f}")) # Сумма

                # Популярные товары (топ-10 по количеству продаж)
                cursor.execute("""
                    SELECT p.name, SUM(oi.quantity) as sold, SUM(oi.quantity * oi.price) as revenue
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.id
                    GROUP BY p.id
                    ORDER BY sold DESC
                    LIMIT 10
                """)
                items = cursor.fetchall() # Получаем список популярных товаров
                self.popular_table.setRowCount(len(items))
                # Настраиваем таблицу
                self.popular_table.setColumnCount(3)
                self.popular_table.setHorizontalHeaderLabels(["Товар", "Продано", "Выручка"])

                # Заполняем таблицу
                for i, row in enumerate(items):
                    self.popular_table.setItem(i, 0, QTableWidgetItem(row["name"])) # Название товара
                    self.popular_table.setItem(i, 1, QTableWidgetItem(str(row["sold"]))) # Продано единиц
                    self.popular_table.setItem(i, 2, QTableWidgetItem(f"{row['revenue']:.2f}")) # Выручка
        finally:
            conn.close()